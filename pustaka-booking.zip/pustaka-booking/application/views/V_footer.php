    <footer>
        <a href="http://www.RentalBuku.com">RentalBuku</a>
    </footer>
</div>
</body>
</html