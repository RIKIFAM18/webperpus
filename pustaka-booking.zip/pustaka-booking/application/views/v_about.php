<section>
    <h1><?php echo $judul ?></h1>
    <h4>Nama</h4>
    <ul type="disc">
        <li>Nama Depan : Kim</li>
        <li>Nama Belakang : Yohana</li>
    </ul>
    <br>
    <h4>Alamat</h4>
    <ul type="none">
        <li> Gangnam, Seoul</li>
    </ul>
 
    <h4>Tempat Lahir</h4>
    <ul type="none">
        <li>Jakarta</li>
    </ul>
    <h4>Olah Raga Favorit</h4>
    <ul type="square">
        <li>Bulutangkis</li>
        <li>`Berjalan</li>
    </ul>
</section>