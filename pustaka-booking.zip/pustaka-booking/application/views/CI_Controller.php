<?php
class Contoh1 extends CI_Controller
{
 public function index()
 {
 echo "<h1>Perkenalkan</h1>";
 echo"Nama Fatia Dewi
 Saya tinggal di daerah Jakarta
 olah raga yang saya sukai adalah
 voli";
 }
}
