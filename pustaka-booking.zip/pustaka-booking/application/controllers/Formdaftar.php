<?php
class Formdaftar extends CI_Controller
{
    public function index()
    {
        $this->form_validation->set_rules('nim', 'NIM', 
'required|min_length[3]', [
            'required' => 'NIM Harus diisi',

        ]);
        $this->form_validation->set_rules('nama', 'Nama', 
'required|min_length[3]', [
            'required' => 'Nama Harus diisi',
        ]);  
        $this->form_validation->set_rules('jeniskelamin', 'Jenis Kelamin', 
'required|min_length[3]', [
            'required' => 'Jenis Kelamin Harus diisi',
        ]);
        $this->form_validation->set_rules('prodi', 'Program Studi',  
'required|min_length[3]', [
            'required' => 'Program Studi Harus diisi',
        ]);
        $this->form_validation->set_rules('angkatan', 'Angkatan', 
'required|min_length[3]', [
            'required' => 'Angkatan Harus diisi',
        ]);
        $this->form_validation->set_rules('kampus', 'Kampus', 
'required|min_length[3]', [
            'required' => 'Kampus Harus diisi',
        ]);
        $this->form_validation->set_rules('tgl', 'Tanggal Lahir', 
'required|min_length[3]', [
            'required' => 'Tanggal Lahir Harus diisi',
        ]);
        $this->form_validation->set_rules('tempat', 'Tempat Lahir', 
'required|min_length[3]', [
            'required' => 'Tempat Lahir Harus diisi',
        ]);
        $this->form_validation->set_rules('email', 'Email', 
'required|min_length[3]', [
            'required' => 'Email Harus diisi',
        ]);
        $this->form_validation->set_rules('alamat', 'Alamat', 
'required|min_length[3]', [
            'required' => 'Alamat Harus diisi',
        ]);
        $this->form_validation->set_rules('hobi', 'Hobi', 
'required|min_length[3]', [
            'required' => 'Hobi Harus diisi',
        ]);
        if ($this->form_validation->run() != true) {
            $this->load->view('view-form-formdaftar');
        } else {

            $data = [
                'nim' => $this->input->post('nim'),
                'nama' => $this->input->post('nama'),
                'jeniskelamin' => $this->input->post('jeniskelamin'),
                'prodi' => $this->input->post('prodi'),
                'prodi' => $this->input->post('prodi'),
                'angkatan' => $this->input->post('angkatan'),
                'kampus' => $this->input->post('kampus'),
                'tgl' => $this->input->post('tgl'),
                'tempat' => $this->input->post('tempat'),
                'email' => $this->input->post('email'),
                'alamat' => $this->input->post('alamat'),
                'hobi' => $this->input->post('hobi')
            ];
            $this->load->view('view-data-formdaftar', $data);
        }
    }
}