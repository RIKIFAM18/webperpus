<?php
class Contoh1 extends CI_Controller
{
    public function index()
    {
        echo "<h1>Perkenalkan</h1>";
        echo "<br>Nama saya Yohana,</br>";
        echo "<br>NIM 19221006</br>";
        echo "<br>Kelas 19.3A.31</br>";
        echo "<br>Saya tinggal di daerah Cililitan</br>";
        echo "<br>olah raga yang saya sukai adalah Bulutangkis</br>";
    }
}